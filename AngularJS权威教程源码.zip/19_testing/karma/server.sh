#!/bin/bash

cd public && python -m SimpleHTTPServer 9000